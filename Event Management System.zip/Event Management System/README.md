# Event-Management
Event Management using SQL
